from django.db import models

class Employee(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    bank_details = models.CharField(max_length=100)
    bank_details_stored_count = models.PositiveIntegerField(default=0)
