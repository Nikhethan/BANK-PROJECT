from django.shortcuts import render
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from .forms import BankDetailsForm
from .models import Employee

def store_bank_details(request):
    if request.method == 'POST':
        form = BankDetailsForm(request.POST)
        if form.is_valid():
            employee = form.save(commit=False)
            employee.bank_details_stored_count += 1
            employee.save()
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        form = BankDetailsForm()
    return render(request, 'bank_details.html', {'form': form})

def change_bank_details(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)
    if employee.bank_details_stored_count >= 2:
        # Send verification request to the employee (e.g., via email)
        # Upon verification, update the bank details
        employee.bank_details = 'New bank details'
        employee.save()
        return JsonResponse({'success': True})
    else:
        return JsonResponse({'success': False, 'message': 'Bank details can only be changed after storing twice.'})
